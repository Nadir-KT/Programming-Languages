#include<stdio.h>
int main(void)
{
   	int a=17,b=4;
	printf("Sum=%d\n",a+b);
	printf("Difference=%d\n",a-b);
	printf("Product=%d\n",a*b);
	printf("Quotient=%d\n",a/b);
	printf("Remainder=%d\n",a%b);	
	return 0;
}
