#include<stdio.h>
int main(void)
{
	int a=11;
	printf("a=%d\t",a);
	printf("a=%o\t",a);
	printf("a=%x\t",a);
	printf("a=%X\n",a);
	return 0;
}
