#include<stdio.h>
int main(void)
{
	printf("Indian\b \n");  							
	printf("New\rDelhi\n");
	return 0;
}
