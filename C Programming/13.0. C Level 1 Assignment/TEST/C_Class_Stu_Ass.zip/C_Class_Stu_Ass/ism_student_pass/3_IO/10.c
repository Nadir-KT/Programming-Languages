#include<stdio.h>
int main(void)
{
	printf("%10s\n","India");
	printf("%4s\n","India");
	printf("%.2s\n","India");
	printf("%5.2s\n","India");
	return 0;
}
