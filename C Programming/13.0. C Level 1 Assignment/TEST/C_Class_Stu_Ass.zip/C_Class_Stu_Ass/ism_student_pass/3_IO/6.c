#include<stdio.h>
int main(void)
{
	float b=123.1265;
	printf("%f\t",b);
	printf("%.2f\t",b);
	printf("%.3f\n",b);
	return 0;
}
