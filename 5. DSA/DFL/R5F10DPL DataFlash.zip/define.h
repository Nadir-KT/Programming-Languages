#define SW1 P6_bit.no0
#define SW2 P6_bit.no1
#define SW3 P13_bit.no7
#define LED1 P13_bit.no2
#define LED2 P13_bit.no3
#define LED3 P13_bit.no4