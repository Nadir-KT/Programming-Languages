/*
*********************************************************************************************************
*                                                78K0/Dx2 Reference Design
*
*                           (c) Copyright 2010.01, NEC Electronics China Automotive Business Unit
*                                           All Rights Reserved
*
* File    : can.h
* By      : Wang Xufang
* Version : V1.0
* Announcement:
* 	This program should be used on your own responsibility.
* 	NEC Electronics Corporation assumes no responsibility for any losses
* 	incurred by customers or third parties arising from the use of this file.
*********************************************************************************************************
*/


#define CAN_S		P3.7
#define	CAN_S_PM	PM3.7

#define	MSGBUF_BASE_ADD	((unsigned long)(0x0F0600))

/*******************************************
 *		CAN register address data
 ********************************************/
#define	ADD_MBUF_00			(MSGBUF_BASE_ADDR + (unsigned short)(0x0000))
#define	ADD_MBUF_01			(MSGBUF_BASE_ADDR + (unsigned short)(0x0010))
#define	ADD_MBUF_02			(MSGBUF_BASE_ADDR + (unsigned short)(0x0020))
#define	ADD_MBUF_03			(MSGBUF_BASE_ADDR + (unsigned short)(0x0030))
#define	ADD_MBUF_04			(MSGBUF_BASE_ADDR + (unsigned short)(0x0040))
#define	ADD_MBUF_05			(MSGBUF_BASE_ADDR + (unsigned short)(0x0050))
#define	ADD_MBUF_06			(MSGBUF_BASE_ADDR + (unsigned short)(0x0060))
#define	ADD_MBUF_07			(MSGBUF_BASE_ADDR + (unsigned short)(0x0070))
#define	ADD_MBUF_08			(MSGBUF_BASE_ADDR + (unsigned short)(0x0080))
#define	ADD_MBUF_09			(MSGBUF_BASE_ADDR + (unsigned short)(0x0090))
#define	ADD_MBUF_10			(MSGBUF_BASE_ADDR + (unsigned short)(0x00a0))
#define	ADD_MBUF_11			(MSGBUF_BASE_ADDR + (unsigned short)(0x00b0))
#define	ADD_MBUF_12			(MSGBUF_BASE_ADDR + (unsigned short)(0x00c0))
#define	ADD_MBUF_13			(MSGBUF_BASE_ADDR + (unsigned short)(0x00d0))
#define	ADD_MBUF_14			(MSGBUF_BASE_ADDR + (unsigned short)(0x00e0))
#define	ADD_MBUF_15			(MSGBUF_BASE_ADDR + (unsigned short)(0x00f0))

void afCAN_Msgbuf_init(void);
void afCAN_init(void);
void tx_msgbuf_processing(unsigned char ,unsigned char  ,unsigned char* );
void rx_msgbuf_init(unsigned char ,unsigned int );
void tx_msgbuf_init(unsigned char ,unsigned int ,unsigned char );


