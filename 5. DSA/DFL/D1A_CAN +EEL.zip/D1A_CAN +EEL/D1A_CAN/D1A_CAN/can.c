/*
*********************************************************************************************************
*                                                78K0/Dx2 Reference Design
*
*                           (c) Copyright 2010.02, NEC Electronics China Automotive Business Unit
*                                           All Rights Reserved
*
* File    : can.c
* By      : Wang Xufang
* Version : V1.0
* Announcement:
* 	This program should be used on your own responsibility.
* 	NEC Electronics Corporation assumes no responsibility for any losses
* 	incurred by customers or third parties arising from the use of this file.
*********************************************************************************************************
*/
/********** declaration ********************************************************************************/
//#pragma	interrupt INTC0REC rx_msgbuf_processing
//#pragma	interrupt INTC0ERR error_processing
//#pragma interrupt INTC0WUP isr_CANWUP
/**********include files********************************************************************************/
#include "can.h"
#include "iodefine.h"
#include "r_cg_macrodriver.h"

#pragma interrupt rx_msgbuf_processing(vect=INTC0REC)
#pragma	interrupt  error_processing(vect=INTC0ERR)
#pragma interrupt  isr_CANWUP(vect=INTC0WUP)

/********** variable definition *************************************************************************/
unsigned char tx_msg_data[8];
unsigned char Rx_Databuf[8];
unsigned char Engine_State,Engine_Stop,buzzer,watertemp_value,Temp,Fuel_level,Oil_level;
/**********************************************************************************
## Module:   	can.c
## Function: 	afCAN_Msgbuf_init()
## Description: CAN message buffer initialization.
## Parameter:	None
## Return��  	void
**********************************************************************************/
void afCAN_Msgbuf_init(void)
{
	unsigned char	buffer_number;
	unsigned long	MsgBuf_address;

	/* Init all message buffer */
	for (buffer_number = 0 ; buffer_number < 16 ; buffer_number++)
	 {
	/*	Set CAN message buffer[n] register address */
	MsgBuf_address = (MSGBUF_BASE_ADD + (0x10 * buffer_number));

	/* Clear TRQ, DN bit */
	*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0006;
	
	/* Clear RDY bit */
	*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0001;

	/* Clear MA0 bit */
	*((__far unsigned char *)(MsgBuf_address + 0x09)) &= 0xf8;
   }
}
/**********************************************************************************
## Module:   	can.c
## Function: 	tx_msgbuf_init()
## Description: CAN transmit message buffer initialization.
## Parameter:	buffer_number: CAN transmit buffer number;
				tx_msg_ID:	   CAN transmit message ID;
				tx_msg_DLC:	   CAN transmit message data length
## Return��  	void
**********************************************************************************/
void tx_msgbuf_init(unsigned char buffer_number,unsigned int tx_msg_ID,unsigned char tx_msg_DLC)
{
		unsigned long	MsgBuf_address;
		
		/*Set CAN message buffer[n] register address */
		MsgBuf_address = (MSGBUF_BASE_ADD + (0x10 * buffer_number));

		/* Set C0MCONFm register */
		*((__far unsigned char *)(MsgBuf_address + 0x09)) = 0x01;      //Transmit message buffer, MA0=1,msg buffer used

		/* Set C0MIDLm,C0MIDHm register */
		*((__far unsigned short *)(MsgBuf_address + 0x0a)) = 0x0000;   //standard frame,C0MIDLm=0x0000;
		*((__far unsigned short *)(MsgBuf_address + 0x0c)) = ((tx_msg_ID << 2) & 0x1fff); //C0MIDHm

		/* Set C0MDLCm register */
		*((__far unsigned char *)(MsgBuf_address + 0x08)) = 0x08;     //set C0MDLCm,data length is 8 bytes

		/* Clear C0MDATAxm register */
		{
			unsigned char data_cnt;
			for(data_cnt = 0 ; data_cnt < tx_msg_DLC ; data_cnt++)
			{
				*((__far unsigned char *)(MsgBuf_address + (0x01 * data_cnt))) = 0x00;    //clear each byte data=0x00
			}
		}

		/* Set C0MCTRLm register */
		#if 1
		*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x001e;    //clear MOW,IE,DN,TRQ bit
									//MOV=0,The message buffer is not overwritten by a newly received data frame.
									//IE=0,Normal message transmission completion interrupt disabled
									//DN=0,A data frame or remote frame is not stored in the message buffer.
									//TRQ=0,No message frame transmitting request that is pending or being transmitted
		#endif
		
		#if 0							
		*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0816;    //clear MOW,DN,TRQ bit
									//set IE=1,Normal message transmission completion interrupt enabled
		#endif
		/* Set RDY bit */
		*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0100;    //set RDY=1,The CAN module can write to the message buffer

}
/**********************************************************************************
## Module:   	can.c
## Function: 	rx_msgbuf_init()
## Description: CAN receive message buffer initialization.
## Parameter:	buffer_number: CAN receive buffer number;
				rx_mask_ID:	   CAN receive buffer mask message ID;
## Return��  	void
**********************************************************************************/
void rx_msgbuf_init(unsigned char buffer_number,unsigned int rx_mask_ID)
{
		unsigned long	MsgBuf_address;
		
		/*Set CAN message buffer[n] register address */
		MsgBuf_address = (MSGBUF_BASE_ADD + (0x10 * buffer_number));

		/* Set C0MCONFm register */
		//*((unsigned char *)(MsgBuf_address + 0x09)) = 0x09;      //Receive message buffer(no mask), MA0=1,msg buffer used
		//*((unsigned char *)(MsgBuf_address + 0x09)) = 0x89;    //OWS=1, receive buffer will overwrite if DN=1
		*((__far unsigned char *)(MsgBuf_address + 0x09)) = 0x11;    //Receive message buffer(mask 1), MA0=1,msg buffer used
		//*((unsigned char *)(MsgBuf_address + 0x09)) = 0x19;    //Receive message buffer(mask 2), MA0=1,msg buffer used
		//*((unsigned char *)(MsgBuf_address + 0x09)) = 0x21;    //Receive message buffer(mask 3), MA0=1,msg buffer used
		//*((unsigned char *)(MsgBuf_address + 0x09)) = 0x29;    //Receive message buffer(mask 4), MA0=1,msg buffer used
		//
		/* Set C0MIDLm,C0MIDHm register */
		*((__far unsigned short *)(MsgBuf_address + 0x0a)) = 0x0000;   //standard frame,C0MIDLm=0x0000;
		*((__far unsigned short *)(MsgBuf_address + 0x0c)) = ((rx_mask_ID << 2) & 0x1fff); //C0MIDHm

		/* Set C0MCTRLm register */
		*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0916;    //clear MOW,DN,TRQ bit
									//MOV=0,The message buffer is not overwritten by a newly received data frame.
									//set IE=1,Valid message reception completion interrupt enabled.
									//DN=0,A data frame or remote frame is not stored in the message buffer.
									//TRQ=0,No message frame transmitting request that is pending or being transmitted
		/* Set RDY bit */
		*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0100;    //set RDY=1,The CAN module can write to the message buffer

}

/**********************************************************************************
## Module:   	can.c
## Function: 	afCAN_init()
## Description: The setting of AFCAN module initialization.
## Parameter:	None
## Return��  	void
**********************************************************************************/
void afCAN_init(void)
{
	//CRxD_Port_PM =	1;			/* P70:CRxD */
	//CRxD_Port =1;					
	//CTxD_Port_PM =  0;
	
	
	
	PM7_bit.no0 =1;			/* P70:CRxD */
					
	PM7_bit.no1 =0;
	P7_bit.no1  =1;	
	
	
	C0GMCS  = 0x00;         	//CAN module clock select
        C0GMCTRL= 0x0100;       	//set GOM=1; enable CAN module operation
        //C0GMABTD= 0x00;
	
    	//C0CTRL = 0x807f;			/*set initialization mode*/
	
	//C0BRP	= 0x03; // 250kbps
	C0BRP	= 0x01;	// 500kbps
	C0BTR	= 0x0104;//0x0202;	//0x0104 = Baud-rate: 500kbps   
	
	//tx_msgbuf_init(1,0x115,8);
	//rx_msgbuf_init(2,0x115);
	//rx_msgbuf_init(3,0x251);
	//rx_msgbuf_init(4,0x251);
	
	C0IE = 0x3f00; //0x221d;
	//C0IE	= 0x3F00;        	//enable the output of the interrupt corresponding to CINTS5 to CINTS0 bits

//	C0MASK1L = 0xFFFF;       	//no mask--don't compare ID
//	C0MASK1H = 0x1FFF;
//	C0MASK2L = 0xFFFF;
//	C0MASK2H = 0x1FFF;
//	C0MASK3L = 0xFFFF;
//	C0MASK3H = 0x1FFF;
//	C0MASK4L = 0xFFFF;
//	C0MASK4H = 0x1FFF;
	
	C0RECIF = 0;
	C0RECMK  = 0;
	C0WUPMK  = 0;
	
	C0CTRL   = 0x817E;   		//clear AL,VALID(no receive valid message),PSMODE1,PSMODE0(no power save mode)
						 		//clear OPMODE2,OPMODE1 and set OPMODE0(normal mode) 
						 		//set CCERC(clear C0ERC and C0INFO registers in initialization mode) 
	//C0CTRL = 0x0502;			/*set self-test mode*/
}

/**********************************************************************************
## Module:   	can.c
## Function: 	tx_msgbuf_processing()
## Description: CAN transmit message buffer processing.
## Parameter:	buffer_number: 	CAN transmit buffer number;
				tx_msg_data:	CAN transmit message data;
				tx_msg_DLC:		CAN transmit message data length
## Return��  	void
**********************************************************************************/
void tx_msgbuf_processing(unsigned char buffer_number,unsigned char tx_msg_DLC,unsigned char* tx_msg_data)
{
		unsigned long	MsgBuf_address;
		unsigned short  C0MCTRLm;
		/*Set CAN message buffer[n] register address */
		MsgBuf_address = (MSGBUF_BASE_ADD + (0x10 * buffer_number));

		/* Check TRQ bit */
		C0MCTRLm = *((__far unsigned char *)(MsgBuf_address + 0x0e));
		if((C0MCTRLm & 0x0002) != 0)
		{
			return;
		}

		/* Clear RDY bit */
		*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0001;    //clear RDY=1,The message buffer can be written by software.
		//C0MCTRLm = *((unsigned char *)(MsgBuf_address + 0x0e));
		
		/* Set C0MDATAxm register */
		if((C0MCTRLm & 0x0001) == 0)
		{
			unsigned char data_cnt;
			
			for(data_cnt = 0 ; data_cnt < tx_msg_DLC ; data_cnt++)
			{
				*((__far unsigned char *)(MsgBuf_address + (0x01 * data_cnt))) = tx_msg_data[data_cnt];    //clear each byte data=0x00
			}
			/* Set RDY bit */
			*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0100;
			/* Set TRQ bit */
			*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0200;
		}
		//C0MCTRLm = *((unsigned char *)(MsgBuf_address + 0x0e));
		while((C0MCTRLm & 0x0002) == 0x0002)
		{
			NOP();
			NOP();
		}
		return;
}


/**********************************************************************************
## Module:   	afCAN.c
## Function: 	rx_msgbuf_processing()
## Description: The CAN interrupt receive message processing.
## Parameter:	None
## Return��  	void
**********************************************************************************/
unsigned short 	rx_msg_ID;
static void __near rx_msgbuf_processing(void)
{
	unsigned long	MsgBuf_address;
	unsigned char	rx_msg_DLC;
	unsigned char	rx_data_cnt;
	
	/* Get receive message buffer number*/
	unsigned char rx_buffer_number;
	
	C0INTS = 0x0002;
	
	rx_buffer_number = C0LIPT;
	
	/*Set CAN message buffer[n] register address */
	MsgBuf_address = (MSGBUF_BASE_ADD + (0x10 * rx_buffer_number));
	
	/* Check DN bit */
	while(((*((__far unsigned short *)(MsgBuf_address + 0x0e))) & 0x2004) != 0) //check DN and MUC bit
	{
		/* Clear DN bit */
		*((__far unsigned short *)(MsgBuf_address + 0x0e)) = 0x0004;

		
		/* Get Rx message information */
		//unsigned char	rx_msg_DLC;
		//unsigned char	rx_data_cnt;
		
		/* Get receive message data length */
		rx_msg_DLC = *((__far unsigned char *)(MsgBuf_address + 0x08));

		/* Get receive message ID*/
		//unsigned short rx_msg_ID;
		rx_msg_ID = *((__far unsigned short *)(MsgBuf_address + 0x0C));
		//rx_msg_ID = ((*((unsigned short *)(MsgBuf_address + 0x0C)))>>2) & (0x07ff);     //standard frame,just need C0MIDHm,C0MIDLm=0x0000
		
		switch(rx_msg_ID)
		{
			case (0x0454):    //ID=0x115 ,buffer 2
			#if 1
					Engine_State = (*((__far unsigned char *)(MsgBuf_address)))&&(0x01);
					if(Engine_State == 0)
					{
						Engine_Stop = 1;
					}
			#endif
					#if 0
					tacho_value = (((*((__far unsigned char *)(MsgBuf_address)))<<8)&(0xFF00)) | (*((unsigned char *)(MsgBuf_address + 0x01)));
					speed_value = *((__far unsigned char *)(MsgBuf_address + 0x02));
					#endif
					break;
			case (0x0944):	 //ID=0x251 ,buffer 3
			#if 1		
					buzzer =  *((__far unsigned char *)(MsgBuf_address));
			#endif
					#if 0
					buzzer = 	 ((*((__far unsigned char *)(MsgBuf_address)))>>5) & 0x03;
					shift_mode = ((*((__far unsigned char *)(MsgBuf_address)))>>4) & 0x01;
					gear = 		 (*((__far unsigned char *)(MsgBuf_address))) & 0x0f;
					#endif
					break;
			case (0x0a44):		 //ID=0x291 ,buffer 
					
					
					#if 1
					//fuel_value = *((unsigned char *)(MsgBuf_address));
					watertemp_value = *((__far unsigned char *)(MsgBuf_address + 0x01));
//					for(rx_data_cnt = 0 ; rx_data_cnt < 4 ; rx_data_cnt++)
//					{
//						CAN_Mileage[rx_data_cnt] = *((unsigned char *)(MsgBuf_address + (0x01 * (rx_data_cnt + 2))));
//					}
					#endif
					break;
			case (0x0D40):		 //ID=0x350 ,buffer 4
			
					Temp =(*((__far unsigned char *)(MsgBuf_address)))&&(0x01);
			
			#if 0
					for(rx_data_cnt = 0 ; rx_data_cnt < 3 ; rx_data_cnt++)
					{
						LED_State[rx_data_cnt] = *((__far unsigned char *)(MsgBuf_address + (0x01 * rx_data_cnt)));
					}
			#endif
					break;
					
			case (0x0508)://(0x0508):		//ID=0x142 , buffer 0 , EMS36_10 DBC_v2.0
					Fuel_level =*((__far unsigned char *)(MsgBuf_address));
				break;
			
			case (0x0494)://(0x0494):		//ID=0x125 , buffer 1 , EMS36_10 DBC_v2.0
					Oil_level =*((__far unsigned char *)(MsgBuf_address));
				
				break;
		}
		#if 1
		/* Get receive data */
		for(rx_data_cnt = 0 ;((rx_data_cnt < rx_msg_DLC) && (rx_data_cnt < 8)) ; rx_data_cnt++)
			{
				Rx_Databuf[rx_data_cnt] = *((__far unsigned char *)(MsgBuf_address + (0x01 * rx_data_cnt)));
			}
		#endif
		//if (((*((unsigned short *)(MsgBuf_address + 0x0e))) & 0x2004) == 0) //check DN and MUC bit
		//{
		//	break;
		//}
		
	}
}
/**********************************************************************************
## Module:   	afCAN.c
## Function: 	afCAN_SleepMode_Setting()
## Description: The CAN sleep mode setting.
## Parameter:	None
## Return��  	void
**********************************************************************************/
void afCAN_SleepMode_Setting(void)
{
	C0CTRL = 0x0810;   //set PSMODE0=1,PSMODE1=0, setting CAN sleep mode
	while((C0CTRL&0x0008) == 0); //check PSMODE0=1
}
/**********************************************************************************
## Module:   	afCAN.c
## Function: 	afCAN_StopMode_Setting()
## Description: The CAN stop mode setting.
## Parameter:	None
## Return��  	void
**********************************************************************************/
void afCAN_StopMode_Setting(void)
{
	afCAN_SleepMode_Setting();
	C0CTRL = 0x1800;   //set PSMODE0=1,PSMODE1=1, setting CAN stop mode
	while((C0CTRL&0x0010) == 0); //check PSMODE1=1
}
/**********************************************************************************
## Module:   	afCAN.c
## Function: 	afCAN_StopMode_Release()
## Description: The CAN stop mode release.
## Parameter:	None
## Return��  	void
**********************************************************************************/
void afCAN_StopMode_Release(void)
{
	C0CTRL = 0x0810;   //clear PSMODE1=0, release stop mode to sleep mode
}
/**********************************************************************************
## Module:   	afCAN.c
## Function: 	afCAN_SleepMode_Release()
## Description: The CAN sleep mode release.
## Parameter:	None
## Return��  	void
**********************************************************************************/
void afCAN_SleepMode_Release(void)
{
	C0CTRL = 0x0008;    //clear PSMODE0=0,release sleep mode by software
	
	#if 0
	//Sleep mode can also be released by a falling edge at the CAN reception pin---wakeup signal
	C0INTS = 0x0020;    //clear CINTS5(Wakeup interrupt)
	#endif
}
/**********************************************************************************
## Module:   	afCAN.c
## Function: 	isr_CANWUP()
## Description: The CAN weakup interupt.
## Parameter:	None
## Return��  	void
**********************************************************************************/
static void __near isr_CANWUP(void)
{
	C0INTS = 0x0020;    //clear CINTS5(Wakeup interrupt)
}

static void __near error_processing(void)
{
	C0INTS = 0x001C;
}

